import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = { appId: "com.codeflow.ai", appName: "CodeFlow AI", webDir: "dist" };
export default config;
