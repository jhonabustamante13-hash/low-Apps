package com.flowapps.taskflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.flowapps.taskflow.data.*
import com.flowapps.taskflow.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        ThemeState.init()
        TaskStore.load()
        setContent { AppTheme(TaskDark, TaskLight) { TaskFlowApp() } }
    }
}
