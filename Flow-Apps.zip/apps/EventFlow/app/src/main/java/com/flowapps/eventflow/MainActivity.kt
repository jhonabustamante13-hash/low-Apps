package com.flowapps.eventflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.flowapps.eventflow.data.*
import com.flowapps.eventflow.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        ThemeState.init()
        EventStore.load()
        setContent { AppTheme(EventDark, EventLight) { EventFlowApp() } }
    }
}
