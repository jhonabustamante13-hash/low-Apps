package com.flowapps.taskflow.ui

import androidx.compose.ui.graphics.Color

val TaskDark = Look(listOf(Color(0xFF0F1B2D), Color(0xFF16324A), Color(0xFF0F3D33)), Color(0xFF34D399), Color(0xFFEAF3F8), 0.2f)
val TaskLight = Look(listOf(Color(0xFFE8EEF5), Color(0xFFDDF3EA)), Color(0xFF1F9D77), Color(0xFF0F1B2D), 0.55f)
