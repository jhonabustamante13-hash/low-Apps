import { useEffect, useRef } from "react";
export default function Particles() {
  const ref = useRef<HTMLCanvasElement>(null);
  useEffect(() => {
    const c = ref.current!, x = c.getContext("2d")!;
    const rm = matchMedia("(prefers-reduced-motion:reduce)").matches;
    const rs = () => { c.width = innerWidth; c.height = innerHeight; };
    rs(); addEventListener("resize", rs);
    const P = Array.from({ length: 34 }, () => ({ x: Math.random() * innerWidth, y: Math.random() * innerHeight, r: Math.random() * 1.8 + .4, v: Math.random() * .3 + .08 }));
    let id = 0;
    const draw = () => {
      x.clearRect(0, 0, c.width, c.height);
      P.forEach(p => { p.y -= p.v; if (p.y < 0) p.y = c.height; x.fillStyle = "rgba(150,170,255,.55)"; x.beginPath(); x.arc(p.x, p.y, p.r, 0, 7); x.fill(); });
      if (!rm) id = requestAnimationFrame(draw);
    };
    draw();
    return () => { cancelAnimationFrame(id); removeEventListener("resize", rs); };
  }, []);
  return <canvas ref={ref} className="cv" />;
}
