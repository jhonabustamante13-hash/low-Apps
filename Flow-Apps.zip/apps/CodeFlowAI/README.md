# CodeFlow AI

App Android de programación con IA (React + TypeScript + Vite + Capacitor), diseño Liquid Glass.

## Generar el APK con GitHub (sin computadora)
1. Sube todo el contenido de esta carpeta a un repositorio nuevo (incluida la carpeta oculta `.github`).
2. Pestaña **Actions** → "Build APK" (corre solo al subir, o con "Run workflow").
3. Al terminar, descarga **CodeFlowAI-APK** en "Artifacts" e instala el APK.

## Ejecutar en una computadora
`npm install` → `npm run dev` (web) · `npm run build` (producción).

## IA real (backend)
La app NO trae claves. Sin backend configurado, las funciones de IA muestran "IA no configurada".
1. Despliega `backend/` (Render, Railway, etc.) con la variable `ANTHROPIC_API_KEY`.
2. En la app, ve a **Perfil** y escribe la dirección `https://...` del backend.
El backend limita a 10 solicitudes por minuto por IP. Usa siempre https.

## Notas
- Los proyectos se guardan en el almacenamiento local del celular.
- El botón de descarga del editor puede no funcionar en el WebView de Android; usa Copiar o Guardar.
- El editor usa resaltado de Java para Kotlin (no hay módulo oficial).
