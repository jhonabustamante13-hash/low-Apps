package com.flowapps.wordflow.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.Normalizer

data class Entry(val w: String, val c: String, val d: String, val e: String)

fun norm(s: String): String =
    Normalizer.normalize(s.lowercase().trim(), Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")

object Dict {
    val all = mutableStateListOf<Entry>()
    val favs = mutableStateListOf<String>()
    val history = mutableStateListOf<String>()

    private fun parse(text: String): List<Entry> {
        val a = JSONArray(text)
        return (0 until a.length()).map {
            val o = a.getJSONObject(it)
            Entry(o.getString("w"), o.optString("c"), o.optString("d"), o.optString("e"))
        }
    }

    fun load(ctx: Context) {
        val map = LinkedHashMap<String, Entry>()
        runCatching {
            ctx.assets.open("diccionario.json").bufferedReader().use { r -> parse(r.readText()).forEach { x -> map[norm(x.w)] = x } }
        }
        val f = File(ctx.filesDir, "usuario.json")
        if (f.exists()) runCatching { parse(f.readText()).forEach { x -> map[norm(x.w)] = x } }
        all.clear(); all.addAll(map.values.sortedBy { norm(it.w) })
        favs.clear(); favs.addAll(Prefs.getString("favs", "").split("|").filter { it.isNotBlank() })
        history.clear(); history.addAll(Prefs.getString("hist", "").split("|").filter { it.isNotBlank() })
    }

    /** Importa JSON [{"w","c","d","e"}] o líneas "palabra;categoría;definición;ejemplo". Devuelve cuántas entradas leyó. */
    fun importText(ctx: Context, text: String): Int {
        val t = text.trim()
        val list: List<Entry> = runCatching {
            if (t.startsWith("[")) parse(t)
            else t.lines().mapNotNull { l ->
                val p = l.split(";")
                if (p.size >= 3 && p[0].isNotBlank()) Entry(p[0].trim(), p[1].trim(), p[2].trim(), p.getOrElse(3) { "" }.trim()) else null
            }
        }.getOrDefault(emptyList())
        if (list.isEmpty()) return 0
        val f = File(ctx.filesDir, "usuario.json")
        val cur = if (f.exists()) runCatching { parse(f.readText()) }.getOrDefault(emptyList()) else emptyList()
        val m = LinkedHashMap<String, Entry>()
        (cur + list).forEach { m[norm(it.w)] = it }
        val arr = JSONArray()
        m.values.forEach { arr.put(JSONObject().put("w", it.w).put("c", it.c).put("d", it.d).put("e", it.e)) }
        f.writeText(arr.toString())
        load(ctx)
        return list.size
    }

    fun find(w: String): Entry? { val n = norm(w); return all.firstOrNull { norm(it.w) == n } }

    fun search(q: String): List<Entry> {
        val n = norm(q)
        if (n.isEmpty()) return all.toList()
        val starts = all.filter { norm(it.w).startsWith(n) }
        val rest = all.filter { !norm(it.w).startsWith(n) && (norm(it.w).contains(n) || norm(it.d).contains(n)) }
        return starts + rest
    }

    fun toggleFav(w: String) {
        if (favs.contains(w)) favs.remove(w) else favs.add(w)
        Prefs.putString("favs", favs.joinToString("|"))
    }

    fun addHistory(w: String) {
        history.remove(w); history.add(0, w)
        while (history.size > 30) history.removeAt(history.size - 1)
        Prefs.putString("hist", history.joinToString("|"))
    }

    fun clearHistory() { history.clear(); Prefs.putString("hist", "") }
}
