package com.flowapps.taskflow.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.flowapps.taskflow.data.Prefs
import kotlinx.coroutines.delay
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset
import java.util.Locale

data class Look(val bg: List<Color>, val accent: Color, val text: Color, val glassA: Float)

val LocalLook = compositionLocalOf { Look(listOf(Color.Black, Color.DarkGray), Color.White, Color.White, 0.3f) }
val LocalFont = compositionLocalOf<FontFamily> { FontFamily.Default }

object ThemeState {
    var mode by mutableIntStateOf(0)
    fun init() { mode = Prefs.getInt("theme", 0) }
    fun set(m: Int) { mode = m; Prefs.putInt("theme", m) }
}

@Composable
fun AppTheme(dark: Look, light: Look, font: FontFamily = FontFamily.Default, content: @Composable () -> Unit) {
    val sys = isSystemInDarkTheme()
    val isDark = when (ThemeState.mode) { 1 -> false; 2 -> true; else -> sys }
    val look = if (isDark) dark else light
    MaterialTheme(colorScheme = if (isDark) darkColorScheme(primary = look.accent) else lightColorScheme(primary = look.accent)) {
        CompositionLocalProvider(LocalLook provides look, LocalFont provides font) { content() }
    }
}

fun money(v: Double): String = "\$" + String.format(Locale.US, "%,.2f", v)

fun daysText(d: Long): String = when {
    d > 0 -> "Faltan $d días"
    d == 0L -> "¡Es hoy!"
    else -> "Pasó hace ${-d} días"
}

@Composable
fun Txt(s: String, size: TextUnit = 15.sp, bold: Boolean = false, alpha: Float = 1f, modifier: Modifier = Modifier, family: FontFamily? = null, maxLines: Int = Int.MAX_VALUE) {
    Text(
        text = s, modifier = modifier, color = LocalLook.current.text.copy(alpha = alpha), fontSize = size,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, fontFamily = family ?: LocalFont.current,
        maxLines = maxLines, overflow = TextOverflow.Ellipsis
    )
}

@Composable
fun GlassBackground(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    val look = LocalLook.current
    val t = rememberInfiniteTransition(label = "bg")
    val d by t.animateFloat(0f, 1f, infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse), label = "d")
    Box(modifier.fillMaxSize().background(Brush.linearGradient(look.bg))) {
        Box(Modifier.size(260.dp).offset(x = (-60 + 80 * d).dp, y = (40 + 30 * d).dp).blur(60.dp).background(look.accent.copy(alpha = 0.45f), CircleShape))
        Box(Modifier.size(220.dp).align(Alignment.BottomEnd).offset(x = (50 - 60 * d).dp, y = (-80 + 40 * d).dp).blur(70.dp).background(look.bg.last().copy(alpha = 0.6f), CircleShape))
        content()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GlassCard(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, onLongClick: (() -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(24.dp)
    val src = remember { MutableInteractionSource() }
    val pressed by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (pressed) 0.97f else 1f, spring(dampingRatio = 0.6f), label = "sc")
    var m = modifier.scale(sc).shadow(10.dp, shape).clip(shape)
        .background(Brush.verticalGradient(listOf(Color.White.copy(look.glassA), Color.White.copy(look.glassA / 3f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.85f), Color.White.copy(0.08f), Color.White.copy(0.4f))), shape)
    if (onClick != null || onLongClick != null) {
        m = m.combinedClickable(interactionSource = src, indication = null, onLongClick = onLongClick, onClick = { onClick?.invoke() })
    }
    Column(m.padding(16.dp), content = content)
}

@Composable
fun GlassButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    val look = LocalLook.current
    val haptic = LocalHapticFeedback.current
    val shape = RoundedCornerShape(50)
    val src = remember { MutableInteractionSource() }
    val p by src.collectIsPressedAsState()
    val sc by animateFloatAsState(if (p) 0.94f else 1f, spring(dampingRatio = 0.5f), label = "b")
    Row(
        modifier.scale(sc).shadow(8.dp, shape).clip(shape)
            .background(Brush.verticalGradient(listOf(look.accent, look.accent.copy(alpha = 0.7f))))
            .border(1.dp, Color.White.copy(0.6f), shape)
            .clickable(interactionSource = src, indication = null, onClick = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); onClick() })
            .padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
fun FloatingNav(items: List<Pair<String, ImageVector>>, selected: Int, onSelect: (Int) -> Unit) {
    val look = LocalLook.current
    val shape = RoundedCornerShape(30.dp)
    Row(
        Modifier.navigationBarsPadding().padding(horizontal = 20.dp, vertical = 12.dp).fillMaxWidth()
            .shadow(14.dp, shape).clip(shape)
            .background(Brush.verticalGradient(listOf(Color.White.copy(look.glassA + 0.05f), Color.White.copy(look.glassA / 2f))))
            .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(0.8f), Color.White.copy(0.1f))), shape)
            .padding(6.dp),
        horizontalArrangement = Arrangement.SpaceEvenly
    ) {
        items.forEachIndexed { i, (label, icon) ->
            val on = i == selected
            val bg by animateColorAsState(if (on) look.accent else Color.Transparent, label = "n")
            val c = if (on) Color.White else look.text
            Column(
                Modifier.weight(1f).clip(RoundedCornerShape(24.dp)).background(bg).clickable { onSelect(i) }.padding(vertical = 8.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(icon, label, tint = c)
                Text(label, color = c, fontSize = 11.sp, maxLines = 1)
            }
        }
    }
}

@Composable
fun Splash(name: String, tagline: String, onDone: () -> Unit) {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) { a.animateTo(1f, tween(900, easing = FastOutSlowInEasing)); delay(500); onDone() }
    GlassBackground {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            GlassCard(Modifier.scale(0.6f + 0.4f * a.value).alpha(a.value)) {
                Txt(name.take(1), 64.sp, true, modifier = Modifier.padding(horizontal = 14.dp))
            }
            Spacer(Modifier.height(20.dp))
            Txt(name, 32.sp, true, modifier = Modifier.alpha(a.value))
            Txt(tagline, alpha = 0.8f, modifier = Modifier.alpha(a.value))
        }
    }
}

@Composable
fun Field(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier, number: Boolean = false) {
    val look = LocalLook.current
    OutlinedTextField(
        value = value, onValueChange = onChange, modifier = modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Decimal else KeyboardType.Text),
        shape = RoundedCornerShape(16.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = look.text, unfocusedTextColor = look.text,
            focusedBorderColor = look.accent, unfocusedBorderColor = look.text.copy(alpha = 0.4f),
            focusedLabelColor = look.text, unfocusedLabelColor = look.text.copy(alpha = 0.7f), cursorColor = look.accent
        )
    )
}

@Composable
fun ProgressBar(p: Float, modifier: Modifier = Modifier) {
    val look = LocalLook.current
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(600), label = "p")
    Box(modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(Color.White.copy(0.25f))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(a).background(look.accent))
    }
}

@Composable
fun Stat(label: String, value: String, modifier: Modifier = Modifier) {
    GlassCard(modifier) { Txt(value, 22.sp, true); Txt(label, 12.sp, alpha = 0.75f) }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DatePick(initial: String, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    val st = rememberDatePickerState(
        initialSelectedDateMillis = runCatching { LocalDate.parse(initial).atStartOfDay(ZoneOffset.UTC).toInstant().toEpochMilli() }.getOrNull()
    )
    DatePickerDialog(
        onDismissRequest = onDismiss,
        confirmButton = {
            TextButton(onClick = {
                st.selectedDateMillis?.let { onPick(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
                onDismiss()
            }) { Text("Aceptar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    ) { DatePicker(state = st) }
}

@Composable
fun SettingsScreen(app: String, extra: @Composable ColumnScope.() -> Unit = {}) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Txt("Ajustes", 28.sp, true)
        GlassCard(Modifier.fillMaxWidth()) {
            Txt("Tema", bold = true)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Sistema", "Claro", "Oscuro").forEachIndexed { i, s ->
                    FilterChip(selected = ThemeState.mode == i, onClick = { ThemeState.set(i) }, label = { Text(s) })
                }
            }
        }
        extra()
        GlassCard(Modifier.fillMaxWidth()) {
            Txt(app, bold = true)
            Txt("Versión 1.0. Tus datos se guardan solo en este dispositivo y no hace falta una cuenta.", 13.sp, alpha = 0.75f)
        }
    }
}
