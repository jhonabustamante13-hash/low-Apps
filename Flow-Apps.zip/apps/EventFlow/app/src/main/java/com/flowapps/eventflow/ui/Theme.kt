package com.flowapps.eventflow.ui

import androidx.compose.ui.graphics.Color

val EventDark = Look(listOf(Color(0xFF1A1040), Color(0xFF2B2A7A), Color(0xFF0F3A8A)), Color(0xFF8B5CF6), Color(0xFFF4F1FF), 0.22f)
val EventLight = Look(listOf(Color(0xFFEDE7FF), Color(0xFFD9E4FF)), Color(0xFF6D4AFF), Color(0xFF1B1740), 0.55f)
