package com.flowapps.taskflow.ui

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.flowapps.taskflow.data.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.TextStyle
import java.util.Locale

private fun newTask(due: String) = Task(System.currentTimeMillis(), "", 1, "Personal", "", due)

@Composable
fun TaskFlowApp() {
    var splash by remember { mutableStateOf(true) }
    if (splash) Splash("TaskFlow", "Haz que el día fluya") { splash = false } else Shell()
}

@Composable
private fun Shell() {
    var tab by remember { mutableIntStateOf(0) }
    var settings by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Task?>(null) }
    BackHandler(settings) { settings = false }
    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = if (settings) -1 else tab,
                    transitionSpec = { fadeIn(tween(300)) togetherWith fadeOut(tween(150)) },
                    label = "nav"
                ) { t ->
                    when (t) {
                        -1 -> SettingsScreen("TaskFlow")
                        0 -> TodayScreen({ edit = it }, { edit = newTask(it) }, { settings = true })
                        1 -> TasksScreen({ edit = it }, { edit = newTask(it) })
                        2 -> CalendarScreen({ edit = it }, { edit = newTask(it) })
                        3 -> ProjectsScreen()
                        else -> StatsScreen()
                    }
                }
            }
            FloatingNav(
                listOf("Hoy" to Icons.Filled.Home, "Tareas" to Icons.Filled.Check, "Agenda" to Icons.Filled.DateRange, "Proyectos" to Icons.Filled.Menu, "Datos" to Icons.Filled.Info),
                if (settings) -1 else tab, { tab = it; settings = false }
            )
        }
    }
    edit?.let { cur -> TaskDialog(cur) { edit = null } }
}

@Composable
private fun Ring(p: Float, d: Dp, label: String) {
    val look = LocalLook.current
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(900), label = "ring")
    Box(Modifier.size(d), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = 16.dp.toPx()
            val sz = Size(this.size.width - s, this.size.height - s)
            drawArc(Color.White.copy(alpha = 0.25f), 0f, 360f, false, topLeft = Offset(s / 2, s / 2), size = sz, style = Stroke(s, cap = StrokeCap.Round))
            drawArc(look.accent, -90f, 360f * a, false, topLeft = Offset(s / 2, s / 2), size = sz, style = Stroke(s, cap = StrokeCap.Round))
        }
        Txt(label, 28.sp, true)
    }
}

@Composable
private fun TaskRow(t: Task, onEdit: () -> Unit) {
    val ctx = LocalContext.current
    val pc = when (t.priority) { 2 -> Color(0xFFFF6B6B); 1 -> Color(0xFFFFC857); else -> Color(0xFF7BD389) }
    GlassCard(Modifier.fillMaxWidth(), onClick = onEdit) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = t.done, onCheckedChange = { TaskStore.upsert(ctx, t.copy(done = it, doneAt = if (it) System.currentTimeMillis() else 0L)) })
            Column(Modifier.weight(1f)) {
                Txt(t.title, 16.sp, true, alpha = if (t.done) 0.55f else 1f)
                Txt(listOf(t.category, t.project, t.due).filter { it.isNotBlank() }.joinToString(" · "), 12.sp, alpha = 0.7f)
            }
            Box(Modifier.size(12.dp).clip(CircleShape).background(pc))
        }
    }
}

@Composable
private fun TodayScreen(onEdit: (Task) -> Unit, onNew: (String) -> Unit, onSettings: () -> Unit) {
    val look = LocalLook.current
    val today = LocalDate.now().toString()
    val dueToday = TaskStore.tasks.filter { it.due == today }
    val doneToday = dueToday.count { it.done }
    val p = if (dueToday.isEmpty()) 0f else doneToday.toFloat() / dueToday.size
    val overdue = TaskStore.tasks.filter { !it.done && it.due.isNotBlank() && it.due < today }
    val pending = dueToday.filter { !it.done }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Txt("Hoy", 32.sp, true, modifier = Modifier.weight(1f))
                IconButton(onClick = onSettings) { Icon(Icons.Filled.Settings, "Ajustes", tint = look.text) }
                GlassButton("Nueva", icon = Icons.Filled.Add) { onNew(today) }
            }
        }
        item {
            GlassCard(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                    Ring(p, 150.dp, "${(p * 100).toInt()}%")
                    Spacer(Modifier.height(8.dp))
                    Txt("$doneToday de ${dueToday.size} tareas de hoy completadas", 14.sp, alpha = 0.85f)
                }
            }
        }
        if (overdue.isNotEmpty()) {
            item { Txt("Atrasadas", 14.sp, true, alpha = 0.8f) }
            items(overdue, key = { "o" + it.id }) { TaskRow(it) { onEdit(it) } }
        }
        item { Txt("Para hoy", 14.sp, true, alpha = 0.8f) }
        if (pending.isEmpty()) item { Txt("No tienes tareas pendientes para hoy.", alpha = 0.75f) }
        items(pending, key = { "p" + it.id }) { TaskRow(it) { onEdit(it) } }
    }
}

@Composable
private fun TasksScreen(onEdit: (Task) -> Unit, onNew: (String) -> Unit) {
    var f by remember { mutableIntStateOf(0) }
    val list = TaskStore.tasks
        .filter { when (f) { 0 -> !it.done; 1 -> it.done; else -> true } }
        .sortedWith(compareBy<Task>({ it.due.isEmpty() }, { it.due }, { -it.priority }))
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt("Tareas", 30.sp, true, modifier = Modifier.weight(1f))
            GlassButton("Nueva", icon = Icons.Filled.Add) { onNew("") }
        }
        Row(Modifier.padding(vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Pendientes", "Completadas", "Todas").forEachIndexed { i, s -> FilterChip(selected = f == i, onClick = { f = i }, label = { Text(s) }) }
        }
        if (list.isEmpty()) Txt("No hay tareas en esta lista.", alpha = 0.75f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 12.dp)) {
            items(list, key = { it.id }) { TaskRow(it) { onEdit(it) } }
        }
    }
}

@Composable
private fun CalendarScreen(onEdit: (Task) -> Unit, onNew: (String) -> Unit) {
    val look = LocalLook.current
    val days = remember { (0..13).map { LocalDate.now().plusDays(it.toLong()) } }
    var sel by remember { mutableStateOf(days[0]) }
    val list = TaskStore.tasks.filter { it.due == sel.toString() }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Txt("Agenda", 30.sp, true)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) {
            items(days, key = { it.toString() }) { d ->
                val on = d == sel
                val bg by animateColorAsState(if (on) look.accent else Color.White.copy(alpha = look.glassA), label = "day")
                val n = TaskStore.tasks.count { it.due == d.toString() && !it.done }
                Column(
                    Modifier.clip(RoundedCornerShape(18.dp)).background(bg).clickable { sel = d }.padding(horizontal = 12.dp, vertical = 10.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    val c = if (on) Color.White else look.text
                    Text(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es")), color = c, fontSize = 12.sp)
                    Text(d.dayOfMonth.toString(), color = c, fontSize = 20.sp)
                    Text(if (n > 0) "•$n" else " ", color = c, fontSize = 11.sp)
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Txt(sel.toString(), 14.sp, true, alpha = 0.8f, modifier = Modifier.weight(1f))
            GlassButton("Añadir", icon = Icons.Filled.Add) { onNew(sel.toString()) }
        }
        Spacer(Modifier.height(10.dp))
        if (list.isEmpty()) Txt("Sin tareas para este día.", alpha = 0.75f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) { items(list, key = { it.id }) { TaskRow(it) { onEdit(it) } } }
    }
}

@Composable
private fun ProjectsScreen() {
    val ctx = LocalContext.current
    val look = LocalLook.current
    var name by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Txt("Proyectos", 30.sp, true)
        Spacer(Modifier.height(10.dp))
        GlassCard(Modifier.fillMaxWidth()) {
            Field(name, { name = it }, "Nuevo proyecto")
            Spacer(Modifier.height(8.dp))
            GlassButton("Crear", icon = Icons.Filled.Add) { TaskStore.addProject(name); name = "" }
        }
        Spacer(Modifier.height(10.dp))
        if (TaskStore.projects.isEmpty()) Txt("Aún no hay proyectos.", alpha = 0.75f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(TaskStore.projects.toList(), key = { it }) { pr ->
                val ts = TaskStore.tasks.filter { it.project == pr }
                val done = ts.count { it.done }
                GlassCard(Modifier.fillMaxWidth()) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) { Txt(pr, 17.sp, true); Txt("$done de ${ts.size} tareas", 12.sp, alpha = 0.75f) }
                        IconButton(onClick = { TaskStore.deleteProject(pr) }) { Icon(Icons.Filled.Delete, "Eliminar", tint = look.text) }
                    }
                    Spacer(Modifier.height(6.dp))
                    ProgressBar(if (ts.isEmpty()) 0f else done.toFloat() / ts.size)
                }
            }
        }
    }
}

@Composable
private fun BarRow(label: String, v: Int, max: Int) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 3.dp)) {
        Txt(label, 13.sp, modifier = Modifier.width(84.dp), maxLines = 1)
        Box(Modifier.weight(1f)) { ProgressBar(if (max == 0) 0f else v.toFloat() / max) }
        Txt("  $v", 13.sp, true)
    }
}

@Composable
private fun StatsScreen() {
    val all = TaskStore.tasks
    val done = all.count { it.done }
    val zone = ZoneId.systemDefault()
    val week = (6 downTo 0).map { LocalDate.now().minusDays(it.toLong()) }
    val perDay = week.map { d -> d to all.count { it.done && it.doneAt > 0 && Instant.ofEpochMilli(it.doneAt).atZone(zone).toLocalDate() == d } }
    val maxDay = perDay.maxOf { it.second }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Txt("Productividad", 30.sp, true)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stat("Totales", all.size.toString(), Modifier.weight(1f))
            Stat("Completadas", done.toString(), Modifier.weight(1f))
            Stat("Avance", if (all.isEmpty()) "0%" else "${done * 100 / all.size}%", Modifier.weight(1f))
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Txt("Completadas, últimos 7 días", bold = true)
            Spacer(Modifier.height(6.dp))
            perDay.forEach { (d, n) -> BarRow(d.dayOfWeek.getDisplayName(TextStyle.SHORT, Locale("es")), n, maxDay) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Txt("Pendientes por prioridad", bold = true)
            Spacer(Modifier.height(6.dp))
            val pend = all.filter { !it.done }
            listOf("Alta" to 2, "Media" to 1, "Baja" to 0).forEach { (l, v) -> BarRow(l, pend.count { it.priority == v }, pend.size) }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Txt("Tareas por categoría", bold = true)
            Spacer(Modifier.height(6.dp))
            TaskStore.categories.forEach { c -> BarRow(c, all.count { it.category == c }, all.size) }
        }
    }
}

@Composable
private fun TaskDialog(t: Task, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var title by remember { mutableStateOf(t.title) }
    var pr by remember { mutableIntStateOf(t.priority) }
    var cat by remember { mutableStateOf(t.category) }
    var proj by remember { mutableStateOf(t.project) }
    var due by remember { mutableStateOf(t.due) }
    var rem by remember { mutableStateOf(t.remind) }
    var pick by remember { mutableStateOf(false) }
    val isNew = TaskStore.tasks.none { it.id == t.id }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (isNew) "Nueva tarea" else "Editar tarea") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field(title, { title = it }, "Título")
                Text("Prioridad")
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Baja", "Media", "Alta").forEachIndexed { i, s -> FilterChip(selected = pr == i, onClick = { pr = i }, label = { Text(s) }) }
                }
                Text("Categoría")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TaskStore.categories.forEach { c -> FilterChip(selected = cat == c, onClick = { cat = c }, label = { Text(c) }) }
                }
                Text("Proyecto")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(selected = proj == "", onClick = { proj = "" }, label = { Text("Ninguno") })
                    TaskStore.projects.forEach { p -> FilterChip(selected = proj == p, onClick = { proj = p }, label = { Text(p) }) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    OutlinedButton(onClick = { pick = true }) { Text(if (due.isEmpty()) "Sin fecha límite" else "Límite: $due") }
                    if (due.isNotEmpty()) TextButton(onClick = { due = ""; rem = false }) { Text("Quitar") }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = rem, enabled = due.isNotEmpty(), onCheckedChange = {
                        rem = it
                        if (it && Build.VERSION.SDK_INT >= 33 &&
                            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
                        ) perm.launch(Manifest.permission.POST_NOTIFICATIONS)
                    })
                    Spacer(Modifier.width(8.dp))
                    Text("Recordarme a las 9:00 del día límite")
                }
                if (rem) Text("Se usa el permiso de notificaciones solo para avisarte de esta tarea.", fontSize = 12.sp)
                if (!isNew) TextButton(onClick = { TaskStore.delete(ctx, t.id); onDismiss() }) { Text("Eliminar tarea") }
            }
        },
        confirmButton = {
            TextButton(enabled = title.isNotBlank(), onClick = {
                TaskStore.upsert(ctx, t.copy(title = title.trim(), priority = pr, category = cat, project = proj, due = due, remind = rem && due.isNotEmpty()))
                onDismiss()
            }) { Text("Guardar") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
    if (pick) DatePick(if (due.isEmpty()) LocalDate.now().toString() else due, { due = it }) { pick = false }
}
