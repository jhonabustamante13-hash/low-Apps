package com.flowapps.galleryx.ui

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.compose.AsyncImage
import coil.decode.VideoFrameDecoder
import com.flowapps.galleryx.data.*
import kotlinx.coroutines.launch
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun GalleryApp() {
    var splash by remember { mutableStateOf(true) }
    if (splash) Splash("GalleryX", "Tus recuerdos, en cristal") { splash = false } else Gate()
}

private fun perms(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO)
    Build.VERSION.SDK_INT >= 29 -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
    else -> arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE)
}

private fun has(ctx: Context): Boolean = perms().all { ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED }

@Composable
private fun Gate() {
    val ctx = LocalContext.current
    var ok by remember { mutableStateOf(has(ctx)) }
    val ask = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { ok = has(ctx) }
    if (ok) Main() else GlassBackground {
        Column(Modifier.align(Alignment.Center).padding(28.dp)) {
            GlassCard(Modifier.fillMaxWidth()) {
                Txt("Necesito acceso a tus fotos y vídeos", 20.sp, true)
                Spacer(Modifier.height(8.dp))
                Txt("GalleryX solo lee los archivos de tu dispositivo para mostrarlos. No sube nada a Internet.", alpha = 0.85f)
                Spacer(Modifier.height(16.dp))
                GlassButton("Dar acceso") { ask.launch(perms()) }
            }
        }
    }
}

private fun share(ctx: Context, ms: List<Media>) {
    if (ms.isEmpty()) return
    val uris = ArrayList(ms.map { it.uri })
    val i = Intent(if (uris.size == 1) Intent.ACTION_SEND else Intent.ACTION_SEND_MULTIPLE).apply {
        type = "*/*"
        if (uris.size == 1) putExtra(Intent.EXTRA_STREAM, uris[0]) else putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris)
        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, "Compartir"))
}

private fun toggle(sel: SnapshotStateList<String>, k: String) { if (k in sel) sel.remove(k) else sel.add(k) }

private fun dur(ms: Long): String { val s = ms / 1000; return "%d:%02d".format(s / 60, s % 60) }

@Composable
private fun Main() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val loader = remember { ImageLoader.Builder(ctx).components { add(VideoFrameDecoder.Factory()) }.build() }
    LaunchedEffect(Unit) { Gallery.load(ctx) }
    var tab by remember { mutableIntStateOf(0) }
    var album by remember { mutableStateOf<String?>(null) }
    var viewer by remember { mutableStateOf<Pair<List<Media>, Int>?>(null) }
    var confirm by remember { mutableStateOf<List<Media>?>(null) }
    val sel = remember { mutableStateListOf<String>() }
    val del = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (r.resultCode == Activity.RESULT_OK) { sel.clear(); viewer = null; scope.launch { Gallery.load(ctx) } }
    }
    BackHandler(viewer != null || sel.isNotEmpty() || album != null) {
        when {
            viewer != null -> { viewer = null }
            sel.isNotEmpty() -> { sel.clear() }
            else -> { album = null }
        }
    }
    fun doDelete(list: List<Media>) {
        val uris = list.map { it.uri }
        if (Build.VERSION.SDK_INT >= 30) {
            del.launch(IntentSenderRequest.Builder(MediaStore.createDeleteRequest(ctx.contentResolver, uris).intentSender).build())
        } else {
            try {
                uris.forEach { ctx.contentResolver.delete(it, null, null) }
                sel.clear(); viewer = null
                scope.launch { Gallery.load(ctx) }
            } catch (e: Exception) {
                Toast.makeText(ctx, "En esta versión de Android no se pudo borrar (pendiente).", Toast.LENGTH_LONG).show()
            }
        }
    }
    val open: (List<Media>, Int) -> Unit = { l, i -> viewer = l to i }
    GlassBackground {
        Column(Modifier.fillMaxSize().statusBarsPadding()) {
            if (sel.isNotEmpty()) SelBar(
                sel.size, { sel.clear() },
                { share(ctx, Gallery.items.filter { it.key in sel }) },
                { sel.forEach { k -> if (k !in Gallery.favs) Gallery.toggleFav(k) }; sel.clear() },
                { confirm = Gallery.items.filter { it.key in sel } }
            )
            Box(Modifier.weight(1f)) {
                AnimatedContent(
                    targetState = tab to album,
                    transitionSpec = { fadeIn(tween(250)) togetherWith fadeOut(tween(150)) },
                    label = "tabs"
                ) { (t, a) ->
                    when (t) {
                        0 -> Grid("Fotos y vídeos", Gallery.items, sel, loader, open)
                        1 -> if (a == null) Albums { album = it } else Grid(a, Gallery.items.filter { it.bucket == a }, sel, loader, open)
                        2 -> Grid("Favoritos", Gallery.items.filter { it.key in Gallery.favs }, sel, loader, open)
                        else -> SettingsScreen("GalleryX") {
                            GlassCard(Modifier.fillMaxWidth()) {
                                Txt("Biblioteca", bold = true)
                                Txt("${Gallery.items.size} archivos encontrados", 13.sp, alpha = 0.75f)
                                Spacer(Modifier.height(8.dp))
                                GlassButton("Actualizar") { scope.launch { Gallery.load(ctx) } }
                            }
                        }
                    }
                }
            }
            FloatingNav(
                listOf("Fotos" to Icons.Filled.Home, "Álbumes" to Icons.Filled.Menu, "Favoritos" to Icons.Filled.Favorite, "Ajustes" to Icons.Filled.Settings),
                tab, { tab = it; album = null; sel.clear() }
            )
        }
        AnimatedVisibility(
            visible = viewer != null,
            enter = fadeIn(tween(250)) + scaleIn(initialScale = 0.92f),
            exit = fadeOut(tween(200)) + scaleOut(targetScale = 0.92f)
        ) {
            viewer?.let { (l, i) ->
                Viewer(l, i, loader, { viewer = null }, { share(ctx, listOf(it)) }, { confirm = listOf(it) })
            }
        }
    }
    confirm?.let { l ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text("¿Eliminar ${l.size} archivo(s)?") },
            text = { Text("Se eliminarán de tu dispositivo. Android te pedirá una confirmación final.") },
            confirmButton = { TextButton(onClick = { confirm = null; doDelete(l) }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancelar") } }
        )
    }
}

@Composable
private fun SelBar(n: Int, onCancel: () -> Unit, onShare: () -> Unit, onFav: () -> Unit, onDelete: () -> Unit) {
    val look = LocalLook.current
    GlassCard(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Cancelar", tint = look.text) }
            Txt("$n seleccionadas", bold = true, modifier = Modifier.weight(1f))
            IconButton(onClick = onFav) { Icon(Icons.Filled.Favorite, "Favorito", tint = look.text) }
            IconButton(onClick = onShare) { Icon(Icons.Filled.Share, "Compartir", tint = look.text) }
            IconButton(onClick = onDelete) { Icon(Icons.Filled.Delete, "Eliminar", tint = look.text) }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Grid(title: String, list: List<Media>, sel: SnapshotStateList<String>, loader: ImageLoader, open: (List<Media>, Int) -> Unit) {
    val look = LocalLook.current
    val groups = remember(list) { list.groupBy { Instant.ofEpochSecond(it.date).atZone(ZoneId.systemDefault()).toLocalDate() }.toList() }
    val fmt = remember { DateTimeFormatter.ofPattern("d 'de' MMMM yyyy", Locale("es")) }
    Column(Modifier.fillMaxSize()) {
        Txt(title, 26.sp, true, modifier = Modifier.padding(start = 20.dp, top = 8.dp, bottom = 4.dp))
        if (list.isEmpty()) Txt("No hay archivos para mostrar.", alpha = 0.7f, modifier = Modifier.padding(20.dp))
        LazyVerticalGrid(
            columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 8.dp, end = 8.dp, bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            groups.forEach { (day, ms) ->
                item(key = "h$day", span = { GridItemSpan(maxLineSpan) }) {
                    Txt(day.format(fmt), 14.sp, true, alpha = 0.85f, modifier = Modifier.padding(start = 8.dp, top = 12.dp, bottom = 4.dp))
                }
                items(ms, key = { it.key }) { m ->
                    val on = m.key in sel
                    Box(
                        Modifier.aspectRatio(1f).clip(RoundedCornerShape(10.dp)).combinedClickable(
                            onClick = { if (sel.isNotEmpty()) toggle(sel, m.key) else open(list, list.indexOf(m)) },
                            onLongClick = { toggle(sel, m.key) }
                        )
                    ) {
                        AsyncImage(
                            model = m.uri, contentDescription = null, imageLoader = loader, contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().then(if (on) Modifier.padding(10.dp).clip(RoundedCornerShape(8.dp)) else Modifier)
                        )
                        if (m.video) Text("▶ ${dur(m.dur)}", color = Color.White, fontSize = 11.sp, modifier = Modifier.align(Alignment.BottomStart).padding(6.dp))
                        if (m.key in Gallery.favs) Icon(Icons.Filled.Favorite, null, tint = Color.White, modifier = Modifier.align(Alignment.BottomEnd).padding(6.dp).size(14.dp))
                        if (on) Icon(Icons.Filled.CheckCircle, "Seleccionada", tint = look.accent, modifier = Modifier.align(Alignment.TopEnd).padding(4.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun Albums(onOpen: (String) -> Unit) {
    val groups = Gallery.items.groupBy { it.bucket }.toList().sortedByDescending { it.second.size }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Txt("Álbumes", 26.sp, true)
        Spacer(Modifier.height(10.dp))
        if (groups.isEmpty()) Txt("No hay álbumes todavía.", alpha = 0.7f)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(groups, key = { it.first }) { (name, ms) ->
                GlassCard(Modifier.fillMaxWidth(), onClick = { onOpen(name) }) {
                    Txt(name, 17.sp, true)
                    Txt("${ms.size} elementos", 13.sp, alpha = 0.75f)
                }
            }
        }
    }
}

@Composable
private fun VideoPlayer(uri: android.net.Uri) {
    val ctx = LocalContext.current
    val player = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(uri)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { player.release() } }
    AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } }, modifier = Modifier.fillMaxSize())
}

@Composable
private fun Viewer(list: List<Media>, start: Int, loader: ImageLoader, onClose: () -> Unit, onShare: (Media) -> Unit, onDelete: (Media) -> Unit) {
    val look = LocalLook.current
    val pager = rememberPagerState(initialPage = start.coerceIn(0, (list.size - 1).coerceAtLeast(0))) { list.size }
    var ui by remember { mutableStateOf(true) }
    var playing by remember(pager.currentPage) { mutableStateOf(false) }
    var info by remember { mutableStateOf(false) }
    val cur = list.getOrNull(pager.currentPage)
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { p ->
            val m = list[p]
            Box(
                Modifier.fillMaxSize().clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { ui = !ui },
                contentAlignment = Alignment.Center
            ) {
                if (m.video && playing && p == pager.currentPage) VideoPlayer(m.uri)
                else {
                    AsyncImage(model = m.uri, contentDescription = m.name, imageLoader = loader, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
                    if (m.video) IconButton(onClick = { playing = true }) {
                        Icon(Icons.Filled.PlayArrow, "Reproducir", tint = Color.White, modifier = Modifier.size(72.dp))
                    }
                }
            }
        }
        if (cur != null) {
            AnimatedVisibility(ui, Modifier.align(Alignment.TopCenter), enter = fadeIn() + slideInVertically { -it }, exit = fadeOut() + slideOutVertically { -it }) {
                GlassCard(Modifier.fillMaxWidth().statusBarsPadding().padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = onClose) { Icon(Icons.Filled.ArrowBack, "Volver", tint = look.text) }
                        Txt(cur.name, bold = true, modifier = Modifier.weight(1f), maxLines = 1)
                        IconButton(onClick = { info = true }) { Icon(Icons.Filled.Info, "Información", tint = look.text) }
                        IconButton(onClick = { Gallery.toggleFav(cur.key) }) {
                            Icon(if (cur.key in Gallery.favs) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorito", tint = look.text)
                        }
                    }
                }
            }
            AnimatedVisibility(ui, Modifier.align(Alignment.BottomCenter), enter = fadeIn() + slideInVertically { it }, exit = fadeOut() + slideOutVertically { it }) {
                GlassCard(Modifier.fillMaxWidth().navigationBarsPadding().padding(10.dp)) {
                    Row(horizontalArrangement = Arrangement.SpaceEvenly, modifier = Modifier.fillMaxWidth()) {
                        IconButton(onClick = { onShare(cur) }) { Icon(Icons.Filled.Share, "Compartir", tint = look.text) }
                        IconButton(onClick = { onDelete(cur) }) { Icon(Icons.Filled.Delete, "Eliminar", tint = look.text) }
                    }
                }
            }
        }
    }
    if (info && cur != null) {
        val fecha = Instant.ofEpochSecond(cur.date).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        val mb = "%.2f".format(cur.size / 1048576.0)
        AlertDialog(
            onDismissRequest = { info = false },
            confirmButton = { TextButton(onClick = { info = false }) { Text("Cerrar") } },
            title = { Text("Información") },
            text = {
                Text(
                    "Nombre: ${cur.name}\nTipo: ${if (cur.video) "Vídeo" else "Foto"}\nTamaño: $mb MB\n" +
                        "Resolución: ${cur.w}×${cur.h}\nÁlbum: ${cur.bucket}\nFecha: $fecha"
                )
            }
        )
    }
}
