package com.flowapps.taskflow

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.flowapps.taskflow.data.Task
import java.time.LocalDate
import java.time.ZoneId

object Reminders {
    private fun code(id: Long): Int = (id % 1_000_000_000L).toInt()

    fun schedule(ctx: Context, t: Task) {
        cancel(ctx, t.id)
        if (!t.remind || t.done || t.due.isBlank()) return
        val at = runCatching { LocalDate.parse(t.due).atTime(9, 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli() }.getOrNull() ?: return
        if (at <= System.currentTimeMillis()) return
        val i = Intent(ctx, ReminderReceiver::class.java).putExtra("title", t.title)
        val pi = PendingIntent.getBroadcast(ctx, code(t.id), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        ctx.getSystemService(AlarmManager::class.java).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    fun cancel(ctx: Context, id: Long) {
        val pi = PendingIntent.getBroadcast(ctx, code(id), Intent(ctx, ReminderReceiver::class.java), PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE)
        if (pi != null) ctx.getSystemService(AlarmManager::class.java).cancel(pi)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val ch = "tareas"
        val nm = c.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(NotificationChannel(ch, "Recordatorios de tareas", NotificationManager.IMPORTANCE_DEFAULT))
        val open = PendingIntent.getActivity(c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(c, ch)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("TaskFlow")
            .setContentText(i.getStringExtra("title") ?: "Tienes una tarea que vence hoy")
            .setContentIntent(open).setAutoCancel(true).build()
        val ok = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
        if (ok) nm.notify((System.currentTimeMillis() % 100000).toInt(), n)
    }
}
