import { useEffect, useState } from "react";
export default function Typewriter({ text }: { text: string }) {
  const [n, setN] = useState(0);
  useEffect(() => {
    if (matchMedia("(prefers-reduced-motion:reduce)").matches) { setN(text.length); return; }
    setN(0);
    const i = setInterval(() => setN(v => { if (v >= text.length) { clearInterval(i); return v; } return v + 4; }), 16);
    return () => clearInterval(i);
  }, [text]);
  return <pre className="out">{text.slice(0, n)}</pre>;
}
