package com.flowapps.wordflow

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.ui.text.font.FontFamily
import com.flowapps.wordflow.data.*
import com.flowapps.wordflow.ui.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Prefs.init(this)
        ThemeState.init()
        Dict.load(this)
        setContent { AppTheme(WordDark, WordLight, FontFamily.Serif) { WordFlowApp() } }
    }
}
